package com.assisconnect.assisconnect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssisconnectApplicationTests {

	@Test
	void contextLoads() {
	}

}
