 package com.assisconnect; // com dois "s"

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssisConnectFront {

    public static void main(String[] args) {
        SpringApplication.run(AssisConnectFront.class, args);
    }
}
