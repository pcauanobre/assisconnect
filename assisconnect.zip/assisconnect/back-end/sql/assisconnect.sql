SELECT * FROM cardapio WHERE dia = 'Segunda';
